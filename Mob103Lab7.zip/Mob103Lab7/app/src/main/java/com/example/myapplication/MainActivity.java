package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    Button btnSave, btnRead;
    EditText txt;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnRead = findViewById(R.id.btnRead);
        btnSave = findViewById(R.id.btnSave);
        txt = findViewById(R.id.txt);
        tv = findViewById(R.id.tv);
        //xu ly su kien ghi du lieu
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = txt.getText().toString();//lay ve chuoi can ghi
                ghDulieu(s);//thuc hien ghi du lieu
            }
        });
        // xu ly su kien doc du lieu
        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = docDulieu();//thuc hien doc du lieu
                tv.setText(String.valueOf(data));//dua len man hinh
            }
        });
    }

    //dinh nghia ham ghi du lieu
    public void ghDulieu(String s) {
        //lay duong dan
        String sdcard =
                Environment.getExternalStorageDirectory().getAbsolutePath() + "/mydata.txt";
        try {
            //tao luong ghi
            OutputStreamWriter streamWriter
                    = new OutputStreamWriter(new FileOutputStream(sdcard));
            streamWriter.write(s);//thuc hien ghi chuoi s vao file
            streamWriter.close();//dong ket noi
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }
    public String docDulieu() {
        String data="";
        String sdcard =
                Environment.getExternalStorageDirectory().getAbsolutePath() + "/mydata.txt";
        try {
            Scanner scanner = new Scanner(new File(sdcard));//tao luong doc
            while (scanner.hasNext())//kiem tra neu khong phai cuoi file
            {
                data += scanner.nextLine()+"\n";//dua du lieu vao data
            }
            scanner.close();//dong ket noi
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
        return data;
    }
}