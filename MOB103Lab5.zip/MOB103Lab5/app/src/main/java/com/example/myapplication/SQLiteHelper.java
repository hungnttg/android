package com.example.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

//lop ho tro ket noi CSDL
public class SQLiteHelper extends SQLiteOpenHelper {
    public static final  String DB_NAME="qlsv";//khai bao ten csdl
    public static final int VERSION=1;//khao bao version csdl

    //phuong thuc khoi tao
    public SQLiteHelper(Context context) {
        super(context, DB_NAME, null, VERSION);
    }
    //phuong thuc tao database
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(LopDAL.SQL_TAOBANG_LOP);//thuc thi cau lenh tao bang
    }
    //phuong thuc cap nhat database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+LopDAL.TABLE_NAME_LOP);//cau lenh xoa bang neu da ton tai
    }
}
