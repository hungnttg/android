package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button btnInsert,btnView;
    EditText txtMaLop, txtTenLop;
    ListView lv;
    List<String> lsLop = new ArrayList<>();//danh sach lop se hien thi len listview
    ArrayAdapter<String> adapter;//adapter ket noi voi nguon du lieu
    LopDAL dal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = findViewById(R.id.lv);
        btnInsert = findViewById(R.id.btnInsert);
        btnView = findViewById(R.id.btnView);
        txtMaLop = findViewById(R.id.txtMaLop);
        txtTenLop = findViewById(R.id.txtTenLop);
        dal = new LopDAL(MainActivity.this);//tao doi tuong dal de su dung
    }

    public void insertLop(View view) {//insert du lieu
        //tao doi tuong lop
        Lop lop = new Lop();
        lop.setMaLop(txtMaLop.getText().toString());//lay du lieu tu ma lop
        lop.setTenLop(txtTenLop.getText().toString());//lay du lieu tu ten lop
        if(dal.insertLop(lop)<0)//thuc hien insert
        {
            Toast.makeText(getApplicationContext(),"Them that bai",Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Them thanh cong",Toast.LENGTH_LONG).show();
        }
    }

    public void viewLop(View view) {//dien du lieu vao listview
      lsLop = dal.getAllMaLop();
        adapter =
                new ArrayAdapter<String>(MainActivity.this,
                        android.R.layout.simple_expandable_list_item_1,lsLop);
        lv.setAdapter(adapter);
    }
}