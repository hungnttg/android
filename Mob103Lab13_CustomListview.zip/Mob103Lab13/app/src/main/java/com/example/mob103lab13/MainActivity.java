package com.example.mob103lab13;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Intent intent;//van chuyen du lieu
    Button btnTinh;//khai bao button
    EditText txtSo1, txtSo2;//khai bao 2 o nhap lieu

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //anh xa: lay thong tin tu XML dua vao code Java
        btnTinh = findViewById(R.id.btnTinh);//anh xa button Tinh
        txtSo1 = findViewById(R.id.txtSo1);//anh xa o nhap lieu so 1
        txtSo2 = findViewById(R.id.txtSo2);//anh xa o nhap lieu so 2
    }
    //ham nay lam nhiem vu dua du lieu vao intent va chuyen qua activity 2
    public void tinhToan(View view) {
        //tao moi intent
        intent = new Intent(MainActivity.this,Main2Activity.class);
        //lay du lieu cua o so 1
        float so1 = Float.parseFloat(txtSo1.getText().toString());
        //dua du lieu o so 1 vao intent
        intent.putExtra("so1",so1);
        //lay du lieu cua o so 2
        float so2 = Float.parseFloat(txtSo2.getText().toString());
        //dua du lieu o so 1 vao intent
        intent.putExtra("so2",so2);
        //van chuyen du lieu sang activity moi
        startActivity(intent);

    }
}
