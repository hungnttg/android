package com.example.mob103lab13;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Lab322Activity extends AppCompatActivity {
    TextView lblKetQua;//khai bao noi hien thi ket qua

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab322);
        lblKetQua = findViewById(R.id.lblKetQua);

        //lay ve intent tu ac1 chuyen qua
        Intent intent = getIntent();
        //doc cac he so
        //lay he so a va ep kieu
        int a = Integer.parseInt(intent.getExtras().getString("hsa"));
        //lay he so b va ep kieu
        int b = Integer.parseInt(intent.getExtras().getString("hsb"));
        //lay he so b va ep kieu
        int c = Integer.parseInt(intent.getExtras().getString("hsc"));
        //tinh delta
        double delta = b*b-4*a*c;
        if(delta<0)
        {
            lblKetQua.setText("PT vo nghiem");
        }
        else if(delta==0)
        {
            lblKetQua.setText("PT co nghiem kep x=: "+ (-b)/(2*a));
        }
        else
        {
            double x1 = (-b+Math.sqrt(delta))/(2*a);
            double x2 = (-b-Math.sqrt(delta))/(2*a);
            lblKetQua.setText("PT co 2 nghiem x1 = "+x1+"; x2= "+x2);
        }

    }
}
