package com.example.mob103lab13;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class La33Activity extends AppCompatActivity {
    ListView lv;//khai bao listview

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_la33);
        //anh xa
        lv = findViewById(R.id.lv);
        displayDataToListview();
    }
    public void displayDataToListview()//ham hien thi du lieu len listview
    {
        //khai bao mang
        String[] arr = new String[]{
                "Phan tu 1","Phan tu 2","Phan tu 3","Phan tu 4","Phan tu 5"
        };
        //tao adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                arr);
        //setAdapter
        lv.setAdapter(adapter);
    }
}
