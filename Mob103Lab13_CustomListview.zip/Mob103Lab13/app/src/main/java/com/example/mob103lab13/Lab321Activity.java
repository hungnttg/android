package com.example.mob103lab13;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Lab321Activity extends AppCompatActivity {
    EditText txtHSA, txtHSB, txtHSC;//khai bao o nhap lieu
    Button btnGiai;//khai bao button giai
    Intent intent;//khai bao intent

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab321);
        //anh xa
        txtHSA = findViewById(R.id.txtHSA);//anh xa txtHSA tu file XML sang file java
        txtHSB = findViewById(R.id.txtHSB);
        txtHSC = findViewById(R.id.txtHSC);
    }

    public void giai(View view) {
        //tao intent (tu Lab321Activity sang Lab322Activity)
        Intent intent = new Intent(Lab321Activity.this,Lab322Activity.class);
        //dua cac he so vao intent
        intent.putExtra("hsa",txtHSA.getText().toString());//dua HSA vao intent
        intent.putExtra("hsb",txtHSB.getText().toString());//dua HSB vao intent
        intent.putExtra("hsc",txtHSC.getText().toString());//dua HSC vao intent
        //start activity voi intent vua tao
        startActivity(intent);
    }
}
