package com.example.mob103lab13;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Lab43Activity extends AppCompatActivity {
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab43);
        lv = findViewById(R.id.lv);
        //tao list contact
        List<Contact> contacts = new ArrayList<>();
        //them du lieu vao list
        contacts.add(new Contact(Color.RED,"Nguyen Van An","0912345678"));
        contacts.add(new Contact(Color.BLUE,"Tran Van B","0902345999"));
        contacts.add(new Contact(Color.GREEN,"Vu Van C","0982888888"));
        //tao adapter
        ContactAdapter adapter = new ContactAdapter(this,R.layout.item_listview,contacts);
        //gan du lieu len listview
        lv.setAdapter(adapter);
    }
}
