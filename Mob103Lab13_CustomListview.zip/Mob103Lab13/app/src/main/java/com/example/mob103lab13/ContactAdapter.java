package com.example.mob103lab13;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ContactAdapter extends ArrayAdapter<Contact> {
    private Context context;//khai bao context
    private int layout;//khai bao layout
    private List<Contact> lsContact;//khai bao danh sach contact
    private LayoutInflater inflater;//doi tuong sinh giao dien
    //phuong thuc khoi tao
    public ContactAdapter(Context context, int resource, List<Contact> objects) {
        super(context, resource, objects);
        this.context = context;
        this.layout = resource;
        this.lsContact = objects;
        //khoi tao giao dien
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //xu ly ham getView: tao view va gan du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = new ViewHolder();//tao moi viewHolder
        //1.tao view
        if(convertView==null)//neu view = null thi tao view moi
        {
            //gan view trong file XML voi convertview trong java
            convertView = inflater.inflate(R.layout.item_listview,null);
            //gan tung truong du lieu
            holder.tvAvatar = (TextView)convertView.findViewById(R.id.tvAvatar);
            holder.tvName = (TextView)convertView.findViewById(R.id.tvName);
            holder.tvPhone = (TextView)convertView.findViewById(R.id.tvPhone);
        }
        else//neu khong bang null thi ta lay ve view
        {
            holder = (ViewHolder)convertView.getTag();//lay ve view
        }
        ///////////
        //2.gan du lieu cho view
        Contact contact = lsContact.get(position);//lay contact tai vi tri position
        holder.tvAvatar.setText(String.valueOf(position));
        holder.tvAvatar.setBackgroundColor(contact.getColor());//thiet lap mau cho Avatar
        holder.tvName.setText(contact.getName());
        holder.tvPhone.setText(contact.getPhone());
        return convertView;
    }

    //Dinh nghia ViewHolder de gan ket voi layout item_listview
    public class ViewHolder
    {
        TextView tvAvatar, tvName, tvPhone;
    }
}
