package com.example.mob103lab13;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    TextView lblKetQua;//khai bao noi hien thi ket qua
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        lblKetQua = findViewById(R.id.lblKetQua);
        Intent intent = getIntent();//lay ve intent tu main chuyen sang

        float so1 = intent.getExtras().getFloat("so1");//lay ve so1 trong intent
        float so2 = intent.getExtras().getFloat("so2");//lay ve so2 trong intent

        float tong = so1+so2;
        float hieu = so1-so2;
        float tich = so1 * so2;
        float thuong = so1/so2;

        String kq = "Tong: "+String.valueOf(tong)
                + " ;Hieu: "+ String.valueOf(hieu)
                +" ;Tich: "+String.valueOf(tich)
                +" ;Thuong: "+String.valueOf(thuong);
        lblKetQua.setText(String.valueOf(kq));
    }
}
