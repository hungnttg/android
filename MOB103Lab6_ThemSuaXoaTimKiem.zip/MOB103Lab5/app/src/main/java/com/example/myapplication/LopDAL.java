package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class LopDAL {
    private Context context;//su dung ngu canh
    SQLiteHelper sqLiteHelper;//su dung file helper
    SQLiteDatabase db;//su dung database
    public static final String TABLE_NAME_LOP="Lop";//ten bang du lieu
    //cau lenh tao bang du lieu
    public static final  String SQL_TAOBANG_LOP=
            "CREATE TABLE Lop ( MaLop text primary key, TenLop text)";
    //phuong thuc khoi tao
    public LopDAL(Context context)
    {
        sqLiteHelper = new SQLiteHelper(context);//khoi tao lop helper
        db = sqLiteHelper.getWritableDatabase();//tao database va cho phep ghi database
    }
    //phuong thuc insert du lieu
    public int insertLop(Lop lop)
    {
        ContentValues values = new ContentValues();//tao doi tuong chua noi dung
        values.put("MaLop",lop.getMaLop());//dua du lieu vao truong ma lop
        values.put("TenLop",lop.getTenLop());//dua du lieu vao truong ten lop
        if(db.insert(TABLE_NAME_LOP,null,values)<0)//insert khong thanh cong
        {
            return -1;
        }
        return 1;//truong hop insert thanh cong
    }
    //phuong thuc lay du lieu
    public List<Lop> getAllLop()
    {
        List<Lop> list = new ArrayList<>();//tao danh sach chua lop
        //tao con tro
        Cursor cursor =
                db.query(TABLE_NAME_LOP,null,null,null,null,null,null);
        cursor.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (cursor.isAfterLast()==false)//neu khong phai la cuoi file
        {
            Lop lop = new Lop();//tao moi 1 lop
            lop.setMaLop(cursor.getString(0));//doc du lieu truong dau tien, gan vao maLop
            lop.setTenLop(cursor.getString(1));//doc du lieu truong thu 2, gan vao tenLop
            list.add(lop);//them doi tuong lop vao danh sach
            cursor.moveToNext();//di chuyen con tro den ban ghi tiep theo
        }
        cursor.close();//sau khi doc du lieu xong, dong con tro
        return list;
    }
    //phuong thuc lay du lieu
    public List<String> getAllMaLop()
    {
        List<String> list = new ArrayList<>();//tao danh sach chua lop
        //tao con tro
        Cursor cursor =
                db.query(TABLE_NAME_LOP,null,null,null,null,null,null);
        cursor.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (cursor.isAfterLast()==false)//neu khong phai la cuoi file
        {
            Lop lop = new Lop();//tao moi 1 lop
            lop.setMaLop(cursor.getString(0));//doc du lieu truong dau tien, gan vao maLop
            lop.setTenLop(cursor.getString(1));
            list.add(lop.getMaLop()+" - "+lop.getTenLop());//them doi tuong lop vao danh sach
            cursor.moveToNext();//di chuyen con tro den ban ghi tiep theo
        }
        cursor.close();//sau khi doc du lieu xong, dong con tro
        return list;
    }

    //phuong thuc lay du lieu
    public List<String> timKiemLop(String tenLop)
    {
        List<String> list = new ArrayList<>();//tao danh sach chua lop
        //tao con tro
        //tim kiem chinh xac
        //Cursor cursor =db.rawQuery("Select MaLop, TenLop from Lop where TenLop like ?", new String[]{tenLop});
        //tim kiem gan dung
        Cursor cursor =
    db.rawQuery("Select MaLop, TenLop from Lop where TenLop like '%"+tenLop+"%'", null);
        cursor.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (cursor.isAfterLast()==false)//neu khong phai la cuoi file
        {
            Lop lop = new Lop();//tao moi 1 lop
            lop.setMaLop(cursor.getString(0));//doc du lieu truong dau tien, gan vao maLop
            lop.setTenLop(cursor.getString(1));
            list.add(lop.getMaLop()+" - "+lop.getTenLop());//them doi tuong lop vao danh sach
            cursor.moveToNext();//di chuyen con tro den ban ghi tiep theo
        }
        cursor.close();//sau khi doc du lieu xong, dong con tro
        return list;
    }



    //phuong thuc lay du lieu
    public List<String> timkiem(String tenLop)
    {
        List<String> list = new ArrayList<>();//tao danh sach chua lop
        //tao con tro

  //tim kiem chinh xac
  //db.rawQuery("Select MaLop, TenLop from Lop where TenLop like ?",new String[]{tenLop});
//tim kiem gan dung
Cursor cursor =
        db.rawQuery("Select MaLop, TenLop from Lop where TenLop like '%"+tenLop+"%'",null);

        cursor.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (cursor.isAfterLast()==false)//neu khong phai la cuoi file
        {
            Lop lop = new Lop();//tao moi 1 lop
            lop.setMaLop(cursor.getString(0));//doc du lieu truong dau tien, gan vao maLop
            lop.setTenLop(cursor.getString(1));
            list.add(lop.getMaLop()+" - "+lop.getTenLop());//them doi tuong lop vao danh sach
            cursor.moveToNext();//di chuyen con tro den ban ghi tiep theo
        }
        cursor.close();//sau khi doc du lieu xong, dong con tro
        return list;
    }

    //phuong thuc sua du lieu
    public int updateLop(Lop lop)
    {
        ContentValues values = new ContentValues();//tao doi tuong chua noi dung
        values.put("MaLop",lop.getMaLop());//dua du lieu vao truong ma lop
        values.put("TenLop",lop.getTenLop());//dua du lieu vao truong ten lop
        //update(tenBang,cacgiaTri,dieuKien,gia tri truyen vao dieu kien)
        if(db.update(TABLE_NAME_LOP,values,"MaLop=?",new String[]{lop.getMaLop()})<=0)//update khong thanh cong
        {
            return -1;
        }
        return 1;//truong hop update thanh cong
    }
    //phuong thuc sua du lieu
    public int deleteLop(String maLop)
    {
        int kq = db.delete(TABLE_NAME_LOP,"MaLop=?",new String[]{maLop});
        if(kq<=0)
        {
            return -1;//xoa khong thanh cong
        }
        return 1;//xoa thanh cong
    }
}
