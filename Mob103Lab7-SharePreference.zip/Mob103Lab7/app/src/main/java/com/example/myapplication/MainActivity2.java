package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {
    Button btnLogin;
    EditText txtU, txtP;
    CheckBox checkBoxLuu;
    private static String tenfile =
            Environment.getExternalStorageDirectory().getAbsolutePath() + "/mydata1.txt";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        //anh xa
        txtP = findViewById(R.id.txtPass);
        txtU = findViewById(R.id.txtUser);
        btnLogin = findViewById(R.id.btnLogin);
        checkBoxLuu = findViewById(R.id.checkBoxLuu);

    }

    public void login(View view) {

        ghiDulieuPreference("a");
    }
    public void ghiDulieuPreference(String tenFile)
    {
        SharedPreferences s
                =getSharedPreferences(tenFile,MODE_PRIVATE);
        SharedPreferences.Editor e = s.edit();
        String username = txtU.getText().toString();
        String password = txtP.getText().toString();
        //bien kiem tra
        boolean ktra = checkBoxLuu.isChecked();//kiem tra xem co check khong
        if(!ktra)//khong check-> xoa
        {
            e.clear();
        }
        else //neu check->luu
        {
            e.putString("username",username);
            e.putString("password",password);
            e.putBoolean("save",ktra);
        }
        e.commit();//thuc hien luu vao file
    }
    public void docDuLieuPrefercence(String tenFile)
    {
        SharedPreferences s
                =getSharedPreferences(tenFile,MODE_PRIVATE);
        boolean ktra = s.getBoolean("save",false);
        if(ktra)//lay du lieu tu file va dien du lueu
        {
            String u = s.getString("username","");
            String p = s.getString("password","");
            txtU.setText(u);
            txtP.setText(p);
        }
        checkBoxLuu.setChecked(ktra);
    }

    public void loadUserPass(View view) {
        docDuLieuPrefercence("a");
    }
}