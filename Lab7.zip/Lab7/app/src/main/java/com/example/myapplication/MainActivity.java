package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    Button btnSavePre, btnReadPre,btnSaveSD,btnReadSD;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtP = findViewById(R.id.txtP);
        txtU = findViewById(R.id.txtU);
        chk = findViewById(R.id.chk);
        txtInput = findViewById(R.id.txtInput);
        tvOutput = findViewById(R.id.tvOutput);
        btnSaveSD = findViewById(R.id.btnSaveSD);
        btnReadSD = findViewById(R.id.btnReadSD);
        btnSavePre = findViewById(R.id.btnSavePre);
        btnReadPre = findViewById(R.id.btnReadPre);
        //xu ly su kien luu
        btnSavePre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        //xu ly su Read
        btnSavePre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String u = txtU.getText().toString();//lay user
                String p = txtP.getText().toString();//lay pass
                boolean ktra = chk.isChecked();//lay check
                saveDataPre(u,p,ktra);//thuc hien luu du lieu
            }
        });
        btnReadPre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                readDataPre();
            }
        });
    }
    public void saveData(String s) {//ghi vao bo nho ngoai
        //lay duong dan
        String sdcard=
                Environment.getExternalStorageDirectory().getAbsolutePath()+"/mydata22.txt";
        try {
            //tao luong ghi
            OutputStreamWriter streamWriter
                    =new OutputStreamWriter(new FileOutputStream(sdcard));
            streamWriter.write(s);//thuc hien ghi
            streamWriter.close();//dong ket noi
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
    public String readData()//doc du lieu tu bo nho ngoai
    {
        String data="";
        //lay duong dan
        String sdcard=
                Environment.getExternalStorageDirectory().getAbsolutePath()+"/mydata22.txt";
        try {
            Scanner scanner = new Scanner(new File(sdcard));//tao luong doc
            while (scanner.hasNext())//kiem tra neu khong phai la cuoi file
            {
                data+=scanner.nextLine()+"\n";//dua du lieu doc duoc vao data
            }
            scanner.close();//dong ket noi
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
        return data;
    }
    public void saveDataPre(String u, String p,boolean ktra)//luu user, pass vao Preference
    {
        SharedPreferences s
                =getSharedPreferences("a",MODE_PRIVATE);//lay duong dan
        SharedPreferences.Editor e = s.edit();//mo file de edit
       if(!ktra) {
           e.clear();//neu khong luu thi xoa
       }
       else {//nguoc lai se luu
           e.putString("username",u);//truyen key va value
           e.putString("password",p);
           e.putBoolean("save",ktra);
       }
       e.commit();//thuc hien luu
    }
    EditText txtU,txtP;
    CheckBox chk;
    public void readDataPre(){//doc du lieu
        SharedPreferences s
                =getSharedPreferences("a",MODE_PRIVATE);//lay duong dan
        boolean ktra = s.getBoolean("save",false);//lay gia tri cua bien Ktra
        if(ktra)//neu dung
        {
            String u = s.getString("username","");//doc tu file theo key
            String p = s.getString("password","");
            txtU.setText(u);
            txtP.setText(p);
        }
        chk.setChecked(ktra);
    }
    EditText txtInput;
    public void saveSD(View view) {
        saveData(txtInput.getText().toString());
    }
    TextView tvOutput;
    public void readSD(View view) {
        String data = readData();
        tvOutput.setText(String.valueOf(data));
    }
}