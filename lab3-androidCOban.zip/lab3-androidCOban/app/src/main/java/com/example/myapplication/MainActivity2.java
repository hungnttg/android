package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    //1.khai bao
    EditText hsa, hsb, hsc;
    Button btnTinh;
    TextView lblKq;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        //2. anh xa
        hsa = findViewById(R.id.hsa);
        hsb = findViewById(R.id.hsb);
        hsc = findViewById(R.id.hsc);
        btnTinh = findViewById(R.id.btngpt);
        lblKq = findViewById(R.id.lblkq);
    }
    public void gpt(View view) {
        //lay du lieu nguoi dung nhap
        float a = Float.parseFloat(hsa.getText().toString());
        float b = Float.parseFloat(hsb.getText().toString());
        float c = Float.parseFloat(hsc.getText().toString());
        //tinh toan
        float delta = b*b-4*a*c;
        if(delta<0){
            lblKq.setText("PT vo nghiem");
        }
        else if(delta==0){
            lblKq.setText("Nghiep kep x="+(-b/(2*a)));
        }
        else {
            float x1 = (float)((-b+Math.sqrt(delta)/(2*a)));
            float x2 = (float)((-b-Math.sqrt(delta)/(2*a)));
            lblKq.setText("2 nghiem x1="+x1+"; x2="+x2);
        }

    }
}