package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity3 extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        listView = findViewById(R.id.lv);
        //1. Tao nguon du lieu
        String[] arr = new String[]{
          "Sinh vien 1",
                "Sinh vien 1",
                "Sinh vien 2",
                "Sinh vien 3",
                "Sinh vien 4",
                "Sinh vien 5",
        };
        //2. Tao adapter
        ArrayAdapter<String> adapter=
                new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,arr);
        //3. Gan du lieu vao listvire
        listView.setAdapter(adapter);
    }
}