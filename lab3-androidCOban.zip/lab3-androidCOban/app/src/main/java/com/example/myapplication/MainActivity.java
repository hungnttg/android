package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //1.Khai bao
    EditText txt1,txt2;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //2. anh xa
        txt1 = findViewById(R.id.txt1);
        txt2 = findViewById(R.id.txt2);
        btn1 = findViewById(R.id.btn1);
    }
    public void dangnhap(View view) {
        if(txt1.getText().toString().equals("admin")
        && txt2.getText().toString().equals("admin"))
        {
            Toast.makeText(getApplicationContext(),"Login thanh cong",
                    Toast.LENGTH_LONG).show();
        } else
        {
            Toast.makeText(getApplicationContext(),"That bai",
                    Toast.LENGTH_LONG).show();
        }
    }
}