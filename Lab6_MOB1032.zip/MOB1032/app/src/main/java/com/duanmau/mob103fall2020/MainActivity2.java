package com.duanmau.mob103fall2020;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    ListView listView;
    List<Lab51Product> list  = new ArrayList<>();
    Lab51Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView = findViewById(R.id.lab51Listview);

        list.add(new Lab51Product("PH01","Nguyen Van A",123,R.mipmap.ic_launcher));
        list.add(new Lab51Product("PH02","Nguyen Van B",234,R.mipmap.ic_launcher));
        list.add(new Lab51Product("PH03","Nguyen Van C",567,R.mipmap.ic_launcher));
        list.add(new Lab51Product("PH04","Nguyen Van D",111,R.mipmap.ic_launcher));
        list.add(new Lab51Product("PH05","Nguyen Van E",333,R.mipmap.ic_launcher));

        adapter = new Lab51Adapter(this,list);
        listView.setAdapter(adapter);

    }
}