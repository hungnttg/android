package com.duanmau.mob103fall2020;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class Lab51Adapter extends BaseAdapter {
    private Context context;//ngu canh
    private List<Lab51Product> arrProduct;//danh sach
    private LayoutInflater inflater;//doi tuong tao layout

    public Lab51Adapter(Context context, List<Lab51Product> arrProduct) {
        this.context = context;
        this.arrProduct = arrProduct;
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //tao lop lien ket voi giao dien XML
    public static class ViewHolder {
        ImageView lab51Img;
        TextView txtId, txtName, txtPrice;
    }

    @Override
    public int getCount() {
        return arrProduct.size();
    }

    @Override
    public Object getItem(int position) {
        return arrProduct.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if(convertView==null)//chua ton tai view thi tao view moi
        {
            viewHolder = new ViewHolder();//tao moi viewHolder
            //gan tung truong
            convertView = inflater.inflate(R.layout.lab51_items,null);//tao layout
            viewHolder.lab51Img = (ImageView)convertView.findViewById(R.id.lab51Img);
            viewHolder.txtId = (TextView)convertView.findViewById(R.id.lab51ID);
            viewHolder.txtName = (TextView)convertView.findViewById(R.id.lab51Name);
            viewHolder.txtPrice = (TextView)convertView.findViewById(R.id.lab51Price);
            //tao template
            convertView.setTag(viewHolder);
        }
        else //neu da ton tai view thi ta lay ve view
        {
            viewHolder = (ViewHolder)convertView.getTag();
        }
        //thiet lap du lieu cho view
        Lab51Product product = arrProduct.get(position);
        viewHolder.lab51Img.setImageResource(product.getImage());
        viewHolder.txtId.setText(product.getId());
        viewHolder.txtName.setText(product.getName());
        viewHolder.txtPrice.setText(String.valueOf(product.getPrice()));
        //tra ve ket qua
        return convertView;
    }
}
