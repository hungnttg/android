package com.duanmau.mob103fall2020;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Lab6Activity extends AppCompatActivity {
    Button btnAdd, btnUpdate, btnDelete, btnDisplay;
    EditText txtUser, txtPass;
    ListView listView;
    ProductDAO productDAO;
    ArrayAdapter<String> arrayAdapter;
    List<String> arrProduct = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab6);
        btnAdd = findViewById(R.id.lab6Add);
        btnDelete = findViewById(R.id.lab6Delete);
        btnDisplay = findViewById(R.id.lab6Display);
        btnUpdate = findViewById(R.id.lab6Update);
        txtUser = findViewById(R.id.lab6txtUser);
        txtPass = findViewById(R.id.lab6txtPass);
        listView = findViewById(R.id.lab6Listview);

        productDAO = new ProductDAO(this);

    }

    public void lab6Add(View view) {
        Product product = new Product();
        product.setUser(txtUser.getText().toString());
        product.setPass(txtPass.getText().toString());
        int result = productDAO.insertProduct(product);
        if(result <=0 )
        {
            Toast.makeText(getApplicationContext(),"Insert not successfull",Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Insert successfull",Toast.LENGTH_LONG).show();
        }
    }

    public void lab6Update(View view) {
        Product product = new Product();
        product.setUser(txtUser.getText().toString());
        product.setPass(txtPass.getText().toString());
        int result = productDAO.updateProduct(product);
        if(result <=0 )
        {
            Toast.makeText(getApplicationContext(),"Update not successfull",Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Update successfull",Toast.LENGTH_LONG).show();
        }

    }

    public void lab6Delete(View view) {
        Product product = new Product();
        product.setUser(txtUser.getText().toString());
        product.setPass(txtPass.getText().toString());
        int result = productDAO.deleteProduct(product.getUser());
        if(result <=0 )
        {
            Toast.makeText(getApplicationContext(),"Delete not successfull",Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Delete successfull",Toast.LENGTH_LONG).show();
        }
    }

    public void lab6Display(View view) {
        arrProduct.clear();
        List<Product> ls = productDAO.getAllProducts();
        for(Product p : ls)
        {
            arrProduct.add(p.getUser() + " - " + p.getPass());
        }
        arrayAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,arrProduct);
        listView.setAdapter(arrayAdapter);
    }
}