package com.duanmau.mob103fall2020;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME="db";
    public static final int VERSION=1;
    public static final String TABLE_NAME1 = "Lab51Product";
    public static final String TAO_BANG_PRODUCT =
            " create table Lab51Product (" +
                    " id text primary key," +
                    " name text," +
                    " price float," +
                    " image integer" +
                    " );";
    //ham khoi tao database
    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, VERSION);
    }
    //tao cac bang du lieu
    @Override
    public void onCreate(SQLiteDatabase db) {
        //db.execSQL(TAO_BANG_PRODUCT);
        db.execSQL(ProductDAO.SQL_PRODUCT);
    }
    //nang cap cac bang du lieu

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ProductDAO.TABLE_NAME);
    }
}
