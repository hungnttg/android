package com.duanmau.mob103fall2020;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText txtSo1, txtSo2;//khai bao dieu khien nhap lieu
    Button btnTong;
    TextView lblKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtSo1 = findViewById(R.id.lab2So1);//anh xa tu file java sang XML: findViewById
        txtSo2 = findViewById(R.id.lab2So2);//anh xa tu file java sang XML: findViewById
        btnTong = findViewById(R.id.lab2Tong);//anh xa tu file java sang XML: findViewById
        lblKQ = findViewById(R.id.lab2KQ);//anh xa tu file java sang XML: findViewById
    }
    //ham tinh tong
    public void tinhTong(View view) {
        //lay so nhap vao tu o 1 va ep kieu sang float
        float s1 = Float.parseFloat(txtSo1.getText().toString());
        //lay so nhap vao tu o 2 va ep kieu sang float
        float s2 = Float.parseFloat(txtSo2.getText().toString());
        //tinh tong
        float tong = s1+s2;
        //dan ket qua len kq
        lblKQ.setText(String.valueOf(tong));
    }

    public void tinhChia(View view) {
        //lay so nhap vao tu o 1 va ep kieu sang float
        float s1 = Float.parseFloat(txtSo1.getText().toString());
        //lay so nhap vao tu o 2 va ep kieu sang float
        float s2 = Float.parseFloat(txtSo2.getText().toString());
        //tinh tong
        float tong = s1/s2;
        //dan ket qua len kq
        lblKQ.setText(String.valueOf(tong));
    }

    public void tinhTru(View view) {
        //lay so nhap vao tu o 1 va ep kieu sang float
        float s1 = Float.parseFloat(txtSo1.getText().toString());
        //lay so nhap vao tu o 2 va ep kieu sang float
        float s2 = Float.parseFloat(txtSo2.getText().toString());
        //tinh tong
        float tong = s1-s2;
        //dan ket qua len kq
        lblKQ.setText(String.valueOf(tong));
    }

    public void tinhNhan(View view) {
        //lay so nhap vao tu o 1 va ep kieu sang float
        float s1 = Float.parseFloat(txtSo1.getText().toString());
        //lay so nhap vao tu o 2 va ep kieu sang float
        float s2 = Float.parseFloat(txtSo2.getText().toString());
        //tinh tong
        float tong = s1*s2;
        //dan ket qua len kq
        lblKQ.setText(String.valueOf(tong));
    }
}
