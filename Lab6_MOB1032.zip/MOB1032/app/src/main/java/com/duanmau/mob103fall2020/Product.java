package com.duanmau.mob103fall2020;

public class Product {
    private String user;
    private String pass;

    public Product(String user, String pass) {
        this.user = user;
        this.pass = pass;
    }

    public Product() {
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
