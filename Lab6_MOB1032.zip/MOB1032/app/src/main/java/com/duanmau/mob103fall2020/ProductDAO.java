package com.duanmau.mob103fall2020;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    private Context context;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;
    public static final String TABLE_NAME = "product";
    public static final String SQL_PRODUCT = "create table product (" +
            " user text primary key, " +
            " pass text );";



    public ProductDAO(Context context) {
        this.context = context;
        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();//cho phep ghi vao db
    }
    //ham them du lieu
    public int insertProduct(Product product)
    {
        ContentValues values = new ContentValues();//tao content chua du lieu
        values.put("user",product.getUser());//dua du lieu vao content
        values.put("pass",product.getPass());
        try {
            if(db.insert(TABLE_NAME,null,values)<0)//thuc hien insert
            {
                return -1;//insert that bai
            }
        }
        catch (Exception e)
        {
            Log.e("Insert: ",e.getMessage());//neu co loi xay ra
        }

        return 1;//insert thanh cong
    }
    //ham lay toan bo du lieu
    public List<Product> getAllProducts()
    {
        List<Product> list = new ArrayList<>();//create empty list//add data to the list
        //create cursor
        Cursor cursor =
                db.query(TABLE_NAME,null,null,
                        null,null,null,null);
        //move cursor to first record
        cursor.moveToFirst();
        //check condition
        while (cursor.isAfterLast()==false)//if is not the last record
        {
            Product product = new Product();//create new product and put data to the product
            product.setUser(cursor.getString(0));
            product.setPass(cursor.getString(1));
            //add the product to list
            list.add(product);
            cursor.moveToNext();//move to next record
        }
        cursor.close();
        //return list
        return list;
    }
    //update data
    public int updateProduct(Product product)
    {
        ContentValues values = new ContentValues();
        values.put("pass",product.getPass());
        int result = db.update(TABLE_NAME,values,"user=?",new String[]{product.getUser()});
        if(result<=0)
        {
            return -1;//update not successful
        }
        return 1;//update successful
    }
    //delete data
    public int deleteProduct(String user)
    {
        int result = db.delete(TABLE_NAME,"user=?",new String[]{user});
        if(result<=0)
        {
            return -1;//delete not successful
        }
        return 1;//delete successful
    }
}
