package lab4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.duanmau.mob103fall2020.R;

public class Lab41MainActivity extends AppCompatActivity {
    EditText txtSoA,txtSoB;
    Button btn;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab41_main);

        txtSoA = findViewById(R.id.lab41txtA);
        txtSoB = findViewById(R.id.lab41txtB);
        btn = findViewById(R.id.lab41Btn);
    }

    public void bscnn(View view) {
        intent = new Intent(this,Lab41SecondActivity.class);
        int a = Integer.parseInt(txtSoA.getText().toString());
        int b = Integer.parseInt(txtSoB.getText().toString());
        Bundle bundle = new Bundle();
        bundle.putInt("key_a",a);
        bundle.putInt("key_b",b);
        intent.putExtra("bun1",bundle);
        startActivity(intent);
    }
}
