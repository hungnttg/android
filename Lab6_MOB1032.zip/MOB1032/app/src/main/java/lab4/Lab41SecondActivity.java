package lab4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.duanmau.mob103fall2020.R;

public class Lab41SecondActivity extends AppCompatActivity {
    TextView tvKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab41_second);
        tvKQ = findViewById(R.id.lab41txtKetQua);

        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("bun1");
        int a1 = bundle.getInt("key_a");
        int a2 = bundle.getInt("key_b");
        int bscnn = 0;
        int bsc = a1 * a2;
        for(int i=1;i<bsc;i++)
        {
            if(i%a1==0 && i%a2==0)
            {
                bscnn = i;
                break;
            }
            else
            {
                bscnn = bsc;
            }
        }
        tvKQ.setText(String.valueOf(bscnn));
    }
}
