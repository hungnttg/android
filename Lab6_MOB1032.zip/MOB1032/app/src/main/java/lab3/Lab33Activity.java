package lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.duanmau.mob103fall2020.R;

public class Lab33Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab33);
        listView = findViewById(R.id.lab33listview);
        fillDataToListview();
    }
    public void fillDataToListview()
    {
        String[] arr = new String[]{
          "Android co ban","Android nang cao","Thiet ke giao dien",
        };
        ArrayAdapter<String> adapter  =
                new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,arr);
        listView.setAdapter(adapter);
    }

}
