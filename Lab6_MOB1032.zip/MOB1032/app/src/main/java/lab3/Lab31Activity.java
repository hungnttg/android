package lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.duanmau.mob103fall2020.R;

public class Lab31Activity extends AppCompatActivity {
    EditText edU, edP;//khai bao

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab31);
        edU = findViewById(R.id.edUser);//anh xa sang file XML
        edP = findViewById(R.id.edPass);//anh xa sang file XML
    }

    public void lab31login(View view) {
        boolean a = edU.getText().toString().equals("admin");
        if((edU.getText().toString().equals("admin"))&&(edP.getText().toString().equals("admin")))
        {
            Toast.makeText(getApplicationContext(),"Dang nhap thanh cong",Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Dang nhap that bai",Toast.LENGTH_LONG).show();
        }
    }
}
