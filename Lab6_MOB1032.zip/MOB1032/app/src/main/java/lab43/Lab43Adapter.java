package lab43;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.duanmau.mob103fall2020.R;

import java.util.ArrayList;
import java.util.List;

public class Lab43Adapter extends BaseAdapter {
    private List<Contact> arrContact;//danh sach
    private Context context;//activity
    LayoutInflater inflater;//ho tro tao giao dien

    public Lab43Adapter(List<Contact> arrContact, Context context) {
        this.arrContact = arrContact;
        this.context = context;
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return arrContact.size();
    }

    @Override
    public Object getItem(int position) {
        return arrContact.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }
    //tao view
    //lay du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewContact viewContact;
        if(convertView==null)//neu chua tao view, tao view moi
        {
            viewContact = new ViewContact();
            convertView = inflater.inflate(R.layout.lab43_items,null);//gan view voi code java
            viewContact.imageView = (ImageView)convertView.findViewById(R.id.lab43img);
            viewContact.txtName = (TextView)convertView.findViewById(R.id.lab43Name);
            viewContact.txtAddress = (TextView)convertView.findViewById(R.id.lab43Address);

            convertView.setTag(viewContact);//tao templete de lan sau dung
        }
        else //neu da co view, lay view ra
        {
            viewContact=(ViewContact)convertView.getTag();
        }
        //lay du lieu
        Contact contact= (Contact)arrContact.get(position);
        viewContact.imageView.setImageResource(R.mipmap.ic_launcher);
        viewContact.txtName.setText(contact.getName());
        viewContact.txtAddress.setText(contact.getAddress());
        //tra ve ket qua
        return convertView;
    }
    public static class ViewContact {
        ImageView imageView;
        TextView txtName;
        TextView txtAddress;
    }
}
