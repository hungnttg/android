package lab43;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.duanmau.mob103fall2020.R;

import java.util.ArrayList;
import java.util.List;

public class Lab43Activity extends AppCompatActivity {
    ListView listView;
    Lab43Adapter adapter;
    List<Contact> ls = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab43);
        listView = findViewById(R.id.lab43listview);
        ls.add(new Contact("Nguyeen Van A","Thanh Xuan",R.mipmap.ic_launcher));
        ls.add(new Contact("Tran Van b","My Dinh",R.mipmap.ic_launcher));
        ls.add(new Contact("Nguyeen Van A","Thanh Xuan",R.mipmap.ic_launcher));
        ls.add(new Contact("Nguyeen Van A","Thanh Xuan",R.mipmap.ic_launcher));
        ls.add(new Contact("Nguyeen Van A","Thanh Xuan",R.mipmap.ic_launcher));
        adapter = new Lab43Adapter(ls,this);
        listView.setAdapter(adapter);

    }
}
