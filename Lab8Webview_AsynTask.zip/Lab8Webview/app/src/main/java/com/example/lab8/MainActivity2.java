package com.example.lab8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpCookie;
import java.net.MalformedURLException;
import java.net.URL;


public class MainActivity2 extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        textView = findViewById(R.id.tvKetQua);
        //goi ham vua viet
        AsyncTask<String,Void,String> content =
                new DocLuong().execute("https://vnexpress.net/");
    }
    public class DocLuong extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... strings) {//doc du lieu tu server
            StringBuilder content = new StringBuilder();//chua noi dung doc
            try {
                URL url = new URL(strings[0]);//duong dan
                //tao luong doc
                InputStreamReader inputStreamReader
                        =new InputStreamReader(url.openConnection().getInputStream());
                //tao bo dem
                BufferedReader bufferedReader
                        =new BufferedReader(inputStreamReader);
                String line="";
                while ((line=bufferedReader.readLine())!=null)//neu khong phai cuoi luong
                {
                    content.append(line);//dua noi dung doc duoc vao content
                }
                bufferedReader.close();//dong ket noi
            } catch (Exception e) {
                e.printStackTrace();
            }
            return content.toString();//tra ve ket qua doc duoc
        }

        @Override
        protected void onPostExecute(String s) {//ham dua ket qua len dien thoai
            super.onPostExecute(s);
            textView.setText(String.valueOf(s));

        }
    }
}