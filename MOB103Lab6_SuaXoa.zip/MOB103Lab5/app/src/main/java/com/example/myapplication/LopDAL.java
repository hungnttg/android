package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class LopDAL {
    private Context context;//su dung ngu canh
    SQLiteHelper sqLiteHelper;//su dung file helper
    SQLiteDatabase db;//su dung database
    public static final String TABLE_NAME_LOP="Lop";//ten bang du lieu
    //cau lenh tao bang du lieu
    public static final  String SQL_TAOBANG_LOP=
            "CREATE TABLE Lop ( MaLop text primary key, TenLop text)";
    //phuong thuc khoi tao
    public LopDAL(Context context)
    {
        sqLiteHelper = new SQLiteHelper(context);//khoi tao lop helper
        db = sqLiteHelper.getWritableDatabase();//tao database va cho phep ghi database
    }
    //phuong thuc insert du lieu
    public int insertLop(Lop lop)
    {
        ContentValues values = new ContentValues();//tao doi tuong chua noi dung
        values.put("MaLop",lop.getMaLop());//dua du lieu vao truong ma lop
        values.put("TenLop",lop.getTenLop());//dua du lieu vao truong ten lop
        if(db.insert(TABLE_NAME_LOP,null,values)<0)//insert khong thanh cong
        {
            return -1;
        }
        return 1;//truong hop insert thanh cong
    }
    //phuong thuc lay du lieu
    public List<Lop> getAllLop()
    {
        List<Lop> list = new ArrayList<>();//tao danh sach chua lop
        //tao con tro
        Cursor cursor =
                db.query(TABLE_NAME_LOP,null,null,null,null,null,null);
        cursor.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (cursor.isAfterLast()==false)//neu khong phai la cuoi file
        {
            Lop lop = new Lop();//tao moi 1 lop
            lop.setMaLop(cursor.getString(0));//doc du lieu truong dau tien, gan vao maLop
            lop.setTenLop(cursor.getString(1));//doc du lieu truong thu 2, gan vao tenLop
            list.add(lop);//them doi tuong lop vao danh sach
            cursor.moveToNext();//di chuyen con tro den ban ghi tiep theo
        }
        cursor.close();//sau khi doc du lieu xong, dong con tro
        return list;
    }
    //phuong thuc lay du lieu
    public List<String> getAllMaLop()
    {
        List<String> list = new ArrayList<>();//tao danh sach chua lop
        //tao con tro
        Cursor cursor =
                db.query(TABLE_NAME_LOP,null,null,null,null,null,null);
        cursor.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (cursor.isAfterLast()==false)//neu khong phai la cuoi file
        {
            Lop lop = new Lop();//tao moi 1 lop
            lop.setMaLop(cursor.getString(0));//doc du lieu truong dau tien, gan vao maLop
            lop.setTenLop(cursor.getString(1));
            list.add(lop.getMaLop()+" - "+lop.getTenLop());//them doi tuong lop vao danh sach
            cursor.moveToNext();//di chuyen con tro den ban ghi tiep theo
        }
        cursor.close();//sau khi doc du lieu xong, dong con tro
        return list;
    }
    //////////////////
    //tao ham update
    public int updateLop(Lop lop)
    {
        ContentValues values = new ContentValues();//tao doi tuong luu du lieu
        values.put("MaLop",lop.getMaLop());//dua ma lop vao values
        values.put("TenLop",lop.getTenLop());//dua ten lop vao values
        //co 4 tham so ham update: tenbang,giatri,dieukhien,gia tri cua dieu kien
        int result =
                db.update(TABLE_NAME_LOP,values,"MaLop=?",new String[]{lop.getMaLop()});
        if(result<=0)
        {
            return -1;//update khong thanh cong
        }
        return 1;//update thanh cong
    }
    public int deleteLop(String maLop)//ham xoa
    {   //co 3 tham so: tenbang,dieuKien,gia tri cua dieu kien
        int result
                =db.delete(TABLE_NAME_LOP,"MaLop=?",new String[]{maLop});
        if(result<=0)
        {
            return -1;//xoa khong thanh cong
        }
        return 1;
    }
}
