package com.example.demomob103.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demomob103.R;

public class MainActivity211 extends AppCompatActivity {
    Button btn1;//click tinh tong
    EditText txt1, txt2;//cho phep nhap lieu
    TextView tvKQ;//hien thi ket qua
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main211);
        //dung findByViewId de anh xa
        btn1 = findViewById(R.id.l22btn1);
        txt1 = findViewById(R.id.l22txt1);
        txt2 = findViewById(R.id.l22txt2);
        tvKQ = findViewById(R.id.l22ketqua);
    }

    public void tinhtong(View view) {
        //lay du lieu nhap vao
        float a = Float.parseFloat(txt1.getText().toString());
        float b = Float.parseFloat(txt2.getText().toString());
        //tinh tong
        float tong = a+b;
        //dua ket qua len man hinh
        tvKQ.setText(String.valueOf(tong));

    }
}