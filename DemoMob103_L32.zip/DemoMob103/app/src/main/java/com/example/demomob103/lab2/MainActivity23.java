package com.example.demomob103.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demomob103.R;

public class MainActivity23 extends AppCompatActivity {
    Button btnCong, btnTru, btnNhan,btnChia;
    EditText txt1, txt2;
    TextView lblKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main23);
        btnCong = findViewById(R.id.l23btnCong);
        btnTru = findViewById(R.id.l23btnTru);
        btnNhan = findViewById(R.id.l23btnNhan);
        btnChia = findViewById(R.id.l23btnChia);
        txt1  = findViewById(R.id.l23txt1);
        txt2 = findViewById(R.id.l23txt2);
    }
    //chuyen du lieu di
    public void cong(View view) {
        //chuan bi dua du lieu tu MainActivity23 -> MainActivity231
        //tao intent de chua du lieu (o to van chuyen du lieu)
        Intent intent = new Intent(MainActivity23.this,MainActivity231.class);
        //dua du lueu vai intent (dua du lieu len o to)
        intent.putExtra("so1",txt1.getText().toString());//dong goi du lieu so 1
        intent.putExtra("so2",txt2.getText().toString());//dong goi du lieu so s
        //cho o to khoi hanh
        startActivity(intent);
    }

    public void tru(View view) {
    }

    public void nhan(View view) {
    }

    public void chia(View view) {
    }
}