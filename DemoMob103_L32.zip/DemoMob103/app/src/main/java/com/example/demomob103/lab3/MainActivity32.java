package com.example.demomob103.lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demomob103.R;
public class MainActivity32 extends AppCompatActivity {
    //1.khai bao
    EditText txta, txtb, txtc;
    Button btnTinh;
    TextView lblkq;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main32);
        //2.anh xa
        txta = findViewById(R.id.l32txta);
        txtb = findViewById(R.id.l32txtb);
        txtc = findViewById(R.id.l32txtc);
        lblkq = findViewById(R.id.l32kq);
        btnTinh = findViewById(R.id.l32Btn);
    }
    //3. tinh toan
    public void l32gpt(View view) {
        //3.1- lay he so a,b,c
        float a = Float.parseFloat(txta.getText().toString());
        float b = Float.parseFloat(txtb.getText().toString());
        float c = Float.parseFloat(txtc.getText().toString());
        //3.2 tinh delta
        float delta = b*b-4*a*c;
        //3.3
        if(delta<0)
        {
            lblkq.setText("Phuong trinh vo nghiem");
        }
        else if(delta==0)
        {
            lblkq.setText("PT co nghiem kep: x="+(-b/(2*a)));
        }
        else
        {
            float x1 = (float) ((-b+Math.sqrt(delta))/(2*a));
            float x2 = (float) ((-b-Math.sqrt(delta))/(2*a));
            lblkq.setText("Nghiem: x1="+x1+"; va x2="+x2);
        }
    }
}