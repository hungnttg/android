package com.example.demomob103;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //alert
        //hien thi thong bao
        Toast.makeText(this,"Xin chao cac ban",Toast.LENGTH_LONG).show();
    }
}