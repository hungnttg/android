package com.example.demomob103.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.demomob103.R;
public class MainActivity231 extends AppCompatActivity {
    TextView txtKq;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main231);
        txtKq = findViewById(R.id.l231Kq);
        //Lay du lieu tu o to dua sang
        Intent intent = getIntent();
        //dua du lieu tu o to xuong dia diem moi
        String str_so1 = intent.getExtras().getString("so1");
        String str_so2 = intent.getExtras().getString("so2");

        float tong = Float.parseFloat(str_so1)+Float.parseFloat(str_so2);
        float hieu = Float.parseFloat(str_so1)-Float.parseFloat(str_so2);
        float tich = Float.parseFloat(str_so1)*Float.parseFloat(str_so2);
        float thuong = Float.parseFloat(str_so1)/Float.parseFloat(str_so2);
        String kq = "Tong: "+tong+"; Hieu: "+hieu+"; Tich: "+tich+"; Thuong: "+thuong;
        //Hien thi ket qua
        txtKq.setText(String.valueOf(kq));
    }
}