package com.example.demomob103.lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.demomob103.R;
public class MainActivity31 extends AppCompatActivity {
    //1.khai bao
    Button btnLogin;
    EditText txtUser, txtPass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main31);
        //2.anh xa
        btnLogin = findViewById(R.id.l31btn);
        txtUser = findViewById(R.id.l31user);
        txtPass = findViewById(R.id.l31pass);
        //3.Lien ket su kien
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txtUser.getText().toString().equals("admin")
                &&txtPass.getText().toString().equals("admin"))
                {
                    Toast.makeText(getApplicationContext(),
                            "Dang nhap thanh cong",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),
                            "Loi Dang nhap",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}